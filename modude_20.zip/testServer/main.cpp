#include <iostream>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <vector>
using namespace std;

#define PORT 7777
#define MESSAGE_LENGTH 1024

int socket_file_descriptor, connection;
vector<int> vecConnections;
int bind_status, connection_status;
struct sockaddr_in addr;
char message[MESSAGE_LENGTH];
int bytes_read;
char buf[MESSAGE_LENGTH];

template <typename T>
void remove(std::vector<T>& v, size_t index) {
    v.erase(v.begin() + index);
}

int main(){
        socket_file_descriptor = socket(AF_INET, SOCK_STREAM, 0);
        if(socket_file_descriptor == -1) {
        cout << "Socket creation failed!" << endl;
        exit(1);
        }

        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        addr.sin_port = htons(PORT);
        addr.sin_family = AF_INET;

        bind_status = bind(socket_file_descriptor, (struct sockaddr*)& addr, sizeof(addr));
        if(bind_status == -1) {
            cout << "Socket binding failed!" << endl;
            exit(1);
        }
        connection_status = listen(socket_file_descriptor, 1);
        if(connection_status == -1) {
            cout << "Socket is unable to listen for new connections" << endl;
            exit(1);
        }
        
        for(int i=0; i<2; i++) {
            connection = accept(socket_file_descriptor, NULL, NULL);
            if(connection == -1) {
                cout << "Server is unable to accept the data from client!" << endl;
                exit(1);
            }
            else {
                cout << "---New connection complete!---" << endl;
                vecConnections.push_back(connection);
            }
        }
        
        while(!vecConnections.empty()) {
            int count = vecConnections.size();
            for(int i=0; i<count; i++) {
                bytes_read = recv(vecConnections.at(i), buf, MESSAGE_LENGTH, 0);
                if((strncmp(buf, "end", 3)) == 0) {
                    remove(vecConnections, i);
                    break;
            }
            cout << buf << endl;
            send(vecConnections.at(i), buf, bytes_read, 0);
            }    
        }
        if(vecConnections.size()==0) cout << "No clients!" << endl;

        close(connection);
        close(socket_file_descriptor);
        return 0;
}