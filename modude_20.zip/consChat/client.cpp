#include "client.h"

Client::Client()
{
    socket_descriptor = socket(AF_INET, SOCK_STREAM, 0);
    if(socket_descriptor == -1) {
        std::cout << "Socket creation failed!" << endl;
    }
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    addr.sin_port = htons(PORT);
    addr.sin_family = AF_INET;

    connection = connect(socket_descriptor, (struct sockaddr*)& addr, sizeof(addr));
    if(connection == -1) {
        std::cout << "Connection with the server failed!" << endl;
    }
}

Client::~Client() 
{
    close (socket_descriptor);
}