#pragma once

#include <iostream>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

using namespace std;

#define MESSAGE_LENGTH 1024
#define PORT 7777

class Client 
{
public:
    int socket_descriptor;
    int connection;
    struct sockaddr_in addr;
    char message[MESSAGE_LENGTH];

    Client();
    ~Client();
};